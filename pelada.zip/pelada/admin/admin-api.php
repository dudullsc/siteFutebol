<?php
require_once __DIR__ . '/../api/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';

try {
    $collection = getMongoCollection();
    switch ($action) {

        case 'listar':
            // Data do jogo mais próxima (sexta)
            $hoje = new DateTime("now", new DateTimeZone('America/Sao_Paulo'));
            $diaDaSemana = (int)$hoje->format('w');
            $diasAteSexta = 5 - $diaDaSemana;
            if ($diasAteSexta <= 0) $diasAteSexta += 7;
            $proximaSexta = clone $hoje;
            $proximaSexta->modify("+$diasAteSexta days");
            $dataJogoFormatada = $proximaSexta->format('d/m');

            $pipeline = [
                ['$match' => ['dataJogo' => $dataJogoFormatada]],
                ['$sort' => ['timestamp' => -1]],
                ['$group' => ['_id' => '$nomeJogador', 'latestStatus' => ['$first' => '$status']]],
                ['$project' => ['_id' => 0, 'nomeJogador' => '$_id', 'status' => '$latestStatus']]
            ];
            $cursor = $collection->aggregate($pipeline);

            $states = new stdClass();
            foreach ($cursor as $doc) {
                $states->{$doc['nomeJogador']} = $doc['status'];
            }

            echo json_encode([
                'status' => 'success',
                'message' => 'Estados carregados',
                'gameDate' => $dataJogoFormatada,
                'states' => $states
            ]);
            break;

        case 'limpar':
            $result = $collection->deleteMany([]);
            echo json_encode([
                'status' => 'success',
                'message' => "Confirmações apagadas ({$result->getDeletedCount()} registros removidos)."
            ]);
            break;

        case 'remover':
            $nome = $_GET['nome'] ?? '';
            if (!$nome) throw new Exception("Nome do jogador não informado.");
            $result = $collection->deleteMany(['nomeJogador' => $nome]);
            echo json_encode([
                'status' => 'success',
                'message' => "$nome removido com sucesso ({$result->getDeletedCount()} registros)."
            ]);
            break;

        case 'renomear':
            $antigo = $_GET['antigo'] ?? '';
            $novo = $_GET['novo'] ?? '';
            if (!$antigo || !$novo) throw new Exception("Parâmetros 'antigo' e 'novo' são obrigatórios.");
            $result = $collection->updateMany(
                ['nomeJogador' => $antigo],
                ['$set' => ['nomeJogador' => $novo]]
            );
            echo json_encode([
                'status' => 'success',
                'message' => "$antigo renomeado para $novo ({$result->getModifiedCount()} registros atualizados)."
            ]);
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Ação inválida']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
